clc
close
clear
 
%Integratory 
%8 30 miss
%A=[2,1,1,0,0;3,3,0,1,0;2,0,0,0,1];
%B=[10;24;8];
%Z=[-1;-1;-1];
%F=[300,200,0,0,0];

%zmienna sztuczna

A=[-2,1;3,3;2,0];
B=[10;24;8];
Z=[-1;-1;-1];
F=[300,200,0,0,0];

WB=[3,4,5];
CB=[F(WB(1)),F(WB(2)),F(WB(3))]
 zm=[0,0,0];
FC=CB*B;
 
for i=1:size(A,2)
    ww(i)=CB*A(:,i)-F(i);    
end
 
[w, KK]=min(ww);
while 1
if( w>=0 )
    disp('koniec')
    FC
    %wartosci zmiennych
    break;
else
    disp('Kolejna tab')
    %szukanie wiersza kluczowego WK
    for i=1:size(A,1)
        if A(i,KK) >0
            t(i)=B(i)./A(i,KK);   %daje zera cza zmienic jesli ominie
        else 
            t(i)=Inf;
        end
    end
    [w,WK]=min(t);
    WB(WK)=KK;
    CB=[F(WB(1)),F(WB(2)),F(WB(3))];
    ER=A(WK,KK);
    B(WK)=B(WK)/ER;
    A(WK,:)=A(WK,:)./ER;
    
    for i=1:size(A,1)
        if (WK~=i)
            B(i)=B(i)-A(i,KK)*B(WK); %cos uzupelnic
            A(i,:)=A(i,:)- A(i,KK)*A(WK,:) 
        end
        
    end
   
    FC=CB*B;
    
    Wynik=zeros(1,size(A,2))
    
   for i=1:size(B)
    Wynik(WB(i))=B(i)
   end
   
   %wprowadzic takie dane zeby skrypt <= >=
   %petla po wierszach Z(i)==-1
   %[1,0,0] bo 3 wiersze mamy i 3 nierownosci
   %na ilu pozycjach z jest -1 luub 1 
   %doklejamy 1 jesli bylo -1 na pierwszej pozycji
   %jedynki po przekatnej daja baze Zmienne sztuczne!
   %2 1 -1 0; 3 3 0 1; 2 0 0 0 
   %A(i,:)=
   
 %od x2=6 x5=4 x1=2   2,6,0,0,4
 
 
    for i=1:size(A,2)
         ww(i)=CB*A(:,i)-F(i);    
    end
    
    [w, KK]=min(ww);
end
end