clc
clear
close


xg = [0,6.5,45,60,87,116,118.5];
xd =[121.5,121.5,116,102,93,85.5,37.5,27.5,19.5,4,0]
yg = [0,5.3,9,15,14.5,5,0];
yd = [0,-5,-9.5,-9.5,-16,-10.5,-9.5,-15.5,-10,-7.5,0]


plot(xg,yg,'*')
plot(yg,yd,'*')

xi=min(xg):0.01:max(xg);
x2=min(xd):0.01:max(xd);

yi=interp1(xg,yg,xi,'cubic')
y2=interp1(xd,yd,x2,'cubic')

