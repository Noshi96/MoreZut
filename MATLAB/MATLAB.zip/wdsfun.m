function [w,k] = wdsfun(D, eta)
 
[m,n] = size(D);
n=n-2;
w=zeros(1, n+1);
k=0;
 
while true
   E = [];
   for i=1:m
       x = D(i,1:n+1);
       y = D(i,end);
       s = w * x';
       f= -1;
       if s>0
            f=1;
       end
       if f~=y
            E=[E;[x y]];
            break;
       end
   
   end
   if isempty(E)
       return
   end
   i = randi([1,size(E,1)]);
   
   x = E(i,1:n+1);
   y = E(i, end);
   w = w+eta*x*y;
   k = k+1;
   
 
   
end
 
end