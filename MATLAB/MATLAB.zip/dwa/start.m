clc
close
clear

czytaj=importdata('dane.txt');

A=czytaj(:,1:end-1);
B=czytaj(:,end);

wynik=bajor_g(A,B)