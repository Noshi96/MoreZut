function [wynik] =bajor_g(A, B)
%wynik=0;
[w,k]=size(A);
%n=size(B,1);
wynik=zeros(n,1);
C=[A B];
for i=1:w
    C(i,:)=C(i,:)./C(i,i);
    for j=1:k
        if i~=j
            C(j,:)=C(j,:)-C(i,:)*C(j,i);
        end
    end
end
wynik=C(:,w+1);
end


