clc
close
clear
 
A=[2,1;3,3;2,0;0,1;1,0];
B=[10;24;8;0;0];
Z=[-1;-1;-1;1;1];
F=[300;200];
 
%1
[W,K]=size(A);
%2,3 isnan, isinf
N=1;
for i=1:W-1
    AT(1,:)=A(i,:);
    BT(1,:)=B(i,:);
for j=i+1:W
    AT(2,:)=A(j,:);
    BT(2,:)=B(j,:);
    R=AT\BT;
    if(~isinf(R) & ~isnan(R))
    T(:,N)=R;
    N=N+1;
    end
end
end
T
[TW,TK]=size(T);
 
test=0;
a=1;
for i=1:TK
    x=T(1,i);
    y=T(2,i);
    for j=1:W
        if(Z(j)==-1)
          if ~( (x*A(j,1)) +(y*A(j,2)) <= B(j))
              test=1;
              break;
          end
        end
        if(Z(j)==0)
            if ~((x*A(j,1)) +(y*A(j,2)) == B(j))
                test=1;
                break;
            end
        end
           
    end
    if(test~=1)
        RD(:,a)=[x,y];
        a=a+1;
    end
    test=0;
end
RD
 
hold on;
X=min(T(1,:))-1:0.01:max(T(1,:));
for i=1:W
    if(A(i,2)~=0)
        Y=(B(i)-A(i,1)*X)/A(i,2);
        plot(X,Y);
    else
        Y=min(T(2,:))-1:0.01:max(T(2,:));
        X=(B(i)/A(i,1)).*ones(length(Y),1);
        plot(X,Y);
    end
end
 
index=convhull(RD(1,:),RD(2,:));
fill(RD(1,index),RD(2,index),'r');
 
[RW,RK]=size(RD);
test=0;
for i=1:RK
    maxi=300*RD(1,i)+200*RD(2,i);
    if maxi > test
        test=maxi;
        maxxy=[RD(1,i),RD(2,i)];
    end
end
 
test
maxxy