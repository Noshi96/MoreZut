clc
clear
close



A=[2,1;3,3;2,0;1,0;0,1]
B=[10;24;8;0;0]
Z=[-1;-1;-1;1;1]
F=[300,200]

ogr=length(Z);
%{
Ile jest ograniczen np liczba wierszy macierzy A
Rozwiazac uklad row liniowych 1 z 2,3,4,5 2   z 1,3,4,5
 odrzucic plus nieskonczonosc
xi y spelnia ograniczenia wszystkie jak uzbiera 5 pkt jest rozwiazaniem
dopuszczalnym
te 5 jako linia
max funkcji celu dla dopuszczalnych
Narysowa� funkcje celu w pynkcie gdzie osiaga max
gause bakslesz 
%}


k=1;
for i=1:ogr-1
    AT(1,:)=A(i,:);
    BT(1,:)=B(i,:);
   for j=i+1:ogr
    AT(2,:)=A(j,:);
    BT(2,:)=B(j,:);
  
  
   R=AT\BT;
   
   if(sum(isnan(R))==0 && sum(isinf(R))==0)
       
   T(:,k)=R;
   k=k+1;
        end
    end
end  
p=1;
for i=1:size(T,2)
    flaga=0;
    for j=1:ogr
        if(Z(j)==-1)
            if(A(j,:)*T(:,i) <= B(j))
           flaga=flaga+1 
            end
        end
        if(Z(j)==1)
           if(A(j,:)*T(:,i)>=B(j))
               flaga=flaga+1
        end
        end
    
        if(Z(j)==0)
           if(A(j,:)*T(:,j)==B(j))
               flaga=flaga+1
        end
        end
       
    end
    
     if(flaga==ogr)  
            tab(:,p)=T(:,i)
            p=p+1
        end
    
end
    tab
hold on
    
 in=convhull(tab(1,:),tab(2,:));
fill(tab(1,in),tab(2,in),'r')
    tab
    for i=1:ogr-1
    x=min(T(1,:)-1:0.1:max(T(1,:)+1))
    y=B(i)-A(i,1)*x./A(i,2)
    plot(x,y)
    end
    
    hold off
    
    %dokonczyc to zadanie bez pkt
    %metoda tabelkowa bedzie
    %sprawdzimy meteode graficzna
    %odkladamy gradienty i do nich wrocimy
    
    
    
    
    
    