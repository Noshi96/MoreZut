function varargout = gid(varargin)
% GID MATLAB code for gid.fig
%      GID, by itself, creates a new GID or raises the existing
%      singleton*.
%
%      H = GID returns the handle to a new GID or the handle to
%      the existing singleton*.
%
%      GID('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GID.M with the given input arguments.
%
%      GID('Property','Value',...) creates a new GID or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gid_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gid_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gid

% Last Modified by GUIDE v2.5 04-Apr-2018 18:04:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gid_OpeningFcn, ...
                   'gui_OutputFcn',  @gid_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gid is made visible.
function gid_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gid (see VARARGIN)

% Choose default command line output for gid
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gid wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gid_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function tbox1_Callback(hObject, eventdata, handles)
% hObject    handle to tbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbox1 as text
%        str2double(get(hObject,'String')) returns contents of tbox1 as a double


% --- Executes during object creation, after setting all properties.
function tbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tfunkcja_Callback(hObject, eventdata, handles)
% hObject    handle to tfunkcja (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tfunkcja as text
%        str2double(get(hObject,'String')) returns contents of tfunkcja as a double


% --- Executes during object creation, after setting all properties.
function tfunkcja_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tfunkcja (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chbox.
function chbox_Callback(hObject, eventdata, handles)
% hObject    handle to chbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chbox


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
grid on
cla

d=get(handles.chbox,'Value');
if(d==1)
    grid on
a = str2double(get(handles.tbox1,'String'));
b = str2double(get(handles.tbox2,'String'));
x = [a:0.01:b];
h = 0.0001;
counter = 0;
 
%f = @(x)((1/3.*x.^2) - (13/7.*x) + 11);
f =str2func(get(handles.tfunkcja,'string'));
df = @(x)(f(x+h) - f(x-h))/(2.*h);
 %df(a);
% df(b);
if ((df(a) < 0) && (df(b) > 0))
   
    z = (3.*(f(a) - f(b))/(b-a)) + df(a) + df(b);
        q = sqrt(z.^2 - df(a).*df(b));
        xm = b - ((df(b) + q - z)/(df(b) - df(a) + 2.*q)) .* (b-a);
        counter = 1;
       
    while (df(xm) > h)
        z = (3.*(f(a) - f(b))/b-a) + df(a) + df(b);
        q = sqrt(z.^2 - df(a).*df(b));
        xm = b - ((df(b) + q - z)/(df(b) - df(a) + 2.*q)) .* (b-a);
        counter = counter + 1;
       
        if (df(xm) < 0)
            a = xm;
        end
       
        if (df(xm) > 0)
            b = xm;
        end
    end
end
 

cla
 axes(handles.axes1)
 plot(x,f(x))
 
 hold on
 plot(xm,f(xm),'*r')
 
set(handles.titeracje,'String',counter)

set(handles.wynik,'String',xm)

else
    cla
	grid on
    set(handles.wynik,'String','Nie wybra�e� metody!')
    set(handles.titeracje,'String','Nie wybra�e� metody!')
end











function titeracje_Callback(hObject, eventdata, handles)
% hObject    handle to titeracje (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of titeracje as text
%        str2double(get(hObject,'String')) returns contents of titeracje as a double


% --- Executes during object creation, after setting all properties.
function titeracje_CreateFcn(hObject, eventdata, handles)
% hObject    handle to titeracje (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tbox2_Callback(hObject, eventdata, handles)
% hObject    handle to tbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbox2 as text
%        str2double(get(hObject,'String')) returns contents of tbox2 as a double


% --- Executes during object creation, after setting all properties.
function tbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function wynik_Callback(hObject, eventdata, handles)
% hObject    handle to wynik (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of wynik as text
%        str2double(get(hObject,'String')) returns contents of wynik as a double


% --- Executes during object creation, after setting all properties.
function wynik_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wynik (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
