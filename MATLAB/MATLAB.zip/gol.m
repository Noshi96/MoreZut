clc
close
clear

tic
hold on;

x=0:0.01:2;

y=@(x)5.*x^2-12.*x-3;

a=min(x);
b=max(x);
Lo=abs(b-a);
alf=(b-(0.618*Lo));
bet=(a+(0.618*Lo));
plot(x,y(x));

if(y(alf)>y(bet))
    a=alf;
    Lo=abs(b-a);
    alf=bet;
    bet=(a+(0.618*Lo);
else
    b=bet;
    Lo=(abs(b-a));
    beta=alfa;
    alfa=(b-(0.618*Lo));
end
    
    
    
    