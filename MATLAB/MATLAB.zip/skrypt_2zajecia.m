clc
close
clear
okno=figure

set(okno)
set(okno,'Name','zajecia2')
set(okno, 'NumberTitle','off')
set(okno,'Color',[0.7,0.8,0.8])
przycisk=uicontrol('Style','pushbutton','String','elooo','Position',[100,100,100,70],'callback','func')
edycja1=uicontrol('Style','edit','String','elooo','Position',[100,200,200,50])
