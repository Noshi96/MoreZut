close
clc
clear


A=[2,1;3,3;2,0;1,0;0,1];
B=[10;24;8;0;0];
Z=[-1;-1;-1;1;1];
F=[300,200];

%ograniczenia ile wierszy A
%12 13 14 15 23 24 25 34 35 45 uklady rownan
%para X Y ktora pasuje do wszystkich rownan dopuszczalne rozw
logra=size(A,1);
k=1;
for i=1:logra-1
   AT(1,:)=A(i,:);
   BT(1,:)=B(i,:);
    for j=i+1:logra
        AT(2,:)=A(j,:);
        BT(2,:)=B(j,:);
        R=AT\BT;
        if (sum(isnan(R))==0)
         if(sum(isinf(R))==0)
            T(:,k)=R;
            k=k+1;
         end
        end
    end
end
flaga=zeros(1,k-1);
k2=1;
for i=1:k-1
    for j=1:logra
        if(Z(j)==-1)
            if((A(j,:)*T(:,i))<=B(j))
                flaga(i)=flaga(i)+1;
            end            
        end
         if(Z(j)==1)
            if(A(j,:)*T(:,i)>=B(j))
                flaga(i)=flaga(i)+1;
            end            
         end
         if(Z(j)==0)
            if(A(j,:)*T(:,i)==B(j))
                flaga(i)=flaga(i)+1;
            end            
        end
    end
    if(flaga(i)==logra)    
        rozw(:,k2)=T(:,i);
        k2=k2+1;        
    end
end


rozw


%convhull
%kolorowanie fiU(,,'r')

%max tak jak w poprzednich labach

%
hold on
X=(min(T(1,:))-1):0.1:(max(T(1,:))+1);
for i=1:logra
    if(A(i,2)~=0)
        Y=(B(i)-A(i,1)*X)/A(i,2);
        plot(X,Y);
    else
        Y=min(T(2,:))-1:0.01:max(T(2,:));
        X=(B(i)/A(i,1)).*ones(length(Y),1);
        plot(X,Y);
    end
end
 

index=convhull(rozw(1,:),rozw(2,:));
fill(rozw(1,index),rozw(2,index),'g');
 
najw=300*rozw(1,1)+200*rozw(2,1);
gdzie=1;
for i=1:k2-1
    nowy=F(1)*rozw(1,1)+F(2)*rozw(2,1);
    if (nowy > najw)
        najw=nowy;
        gdzie=i;
    end
end
    
x2=-1:0.1:9;
y=(najw-F(1)*x2)/F(2);
  plot(rozw(1,1),rozw(2,1),'*r')
    plot(x2,y,'r')



