tic
[x,y]=meshgrid([-3:0.1:3],[-3:0.1:3]);
% Rosenbrock
z=@(x,y) (100.*(y-x.^2).^2+(1-x).^2)

subplot(2,1,1)
mesh(x,y,z(x,y))
%colormap(hot)

subplot(2,1,2)
[c,h]=contour(x,y,z(x,y))
title('Mtoda: mesh ')
axis square
clabel(c,h)
hold on
dx=[-8,-2,-2,0];
dy=[-5,-5,0,0];

plot(dx(1), dy(1), 'r*')
text(dx(1), dy(1), 'START')

plot(dx(end), dy(end), 'r*')
text(dx(end), dy(end), 'STOP')

plot(dx(2:end-1), dy(2:end-1), 'g.')
plot(dx,dy)



 
toc
%To ma by� w odpowiedzi
%xy minimum(szukac bedziemy)
% wartosc funkcji w punkcie minium
%liczba iteracji(liczba odcinkow kiedy sie przesunal)
%czas tic toc
%za 2 tyg funkcja jednej zmiennej
%iterfejs graficzny+2pkt
% gradienty nieobciazone


%af=
%x0=
%y0=
%krok=
%dok=0.01

%znajdz najmniejsza albo min(wektor i na ktorej pozycji)
%zmniejszamy krok
%x0=x0+k
%na ifach albo case switch
%przeszukujemy 4 kierunki
%jesli sie powtarza to optymalizowac
%while krok jest wiekszy od dok�adnosci to wykonuj
%je�li min to zmnmiejsz krok
