function [ wynik ] =swora_g(A,B)
[w,k]=size(A);
C=[A B];
for i=1:w
    if(C(i,i)==0)
        C(i,:)=C(i,:)+C(i+1,:);
    end
    C(i,:)=C(i,:)./C(i,i);
  
    for j=i+1:w
        C(j,:)=C(j,:)-C(j,i)*C(i,:);   
    end
    wynik=C;
end
D=zeros(w,1);
D(w)=C(w,k+1);
for i=w:-1:2
    D(i-1,1)=C(i-1,k+1)-sum(C(i-1,1:end-1)*D);
end
D
