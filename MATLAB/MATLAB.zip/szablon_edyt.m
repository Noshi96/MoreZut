clear
clc
close

tic



%[x,y]=meshgrid([-5:0.1:5],[-5:0.1:5]);
[x,y]=meshgrid([-2:0.1:2],[-1:0.1:3]);
%[x,y]=meshgrid([-20:0.1:20],[-20:0.1:20]);

%f = @(x,y) x.^2 + y.^2;
f = @(x,y) 100.*(y-x.^2)+(1-x).^2;
%f = @(x,y) -cos(x).*cos(y).*exp(-((x-pi).^2 + (y-pi).^2));

subplot(2,1,1)
mesh(x,y,f(x,y))  
colormap(hot)
subplot(2,1,2)
[c,h]=contour(x,y,f(x,y))
title('Wykres');
%axis square
clabel(c,h)
hold on


x0=-1;
y0=-1;

krok=1;
dok=0.001;

%i=1;

dx(1)=x0;
dy(1)=y0;
%flaga=0;
%while(krok>dok && flaga<3)
%while(1)
    
 %   f0=f(x0,y0);
%f1=f(x0,y0+krok);
%f2=f(x0+krok,y0);
%f3=f(x0,y0-krok);
%f4=f(x0-krok,y0);
    
   % [w,p]=min([f0,f1,f2,f3,f4]);
    
     %   i=i+1
        
    %if(p==1)
      %  krok=krok/2;
     %   flaga=flaga+1;
    %end
    
    %if(p==2)
      %  x0=x0+krok;
     %   flaga=0;
    %end 
    
    %if(p==3)
    %    x0=x0-krok;
   %     flaga=0;
  %  end 
    
    %if(p==4)
      %  y0=y0+krok;
     %   flaga=0;
    %end
    
    %if(p==5)
      % y0=y0-krok;
     %   flaga=0;
    %end 
    %if (krok<dok)
     %   flaga=3
    %end
   % if (flaga==3)
  %      return
 %   end
    
%end
i=1;
stop=0;
while (krok>dok)
   [w, p] = min ([f(x0, y0), f(x0, y0+krok), f(x0+krok, y0), f(x0, y0-krok), f(x0-krok, y0)]);
   i=i+1;
   switch(p)
       case 1
           stop=stop+1;
           krok=krok/2;
           dx(i+1)=x0;
           dy(i+1)=y0;
        %   if(stop>10)
           %    break;
           %end
           continue;
       case 2
           stop=0;
           x0=x0;
           y0=y0+krok;
           dx(i+1)=x0;
           dy(i+1)=y0;
           continue;
       case 3
           stop=0;
           x0=x0+krok;
           y0=y0;
           dx(i+1)=x0;
           dy(i+1)=y0;
           continue;
       case 4
           stop=0;
           x0=x0;
           y0=y0-krok;
           dx(i+1)=x0;
           dy(i+1)=y0;
           continue;
       case 5 
           stop=0
           x0=x0-krok;
           y0=y0;
           dx(i+1)=x0;
           dy(i+1)=y0;
           continue;
   end
end
i
plot(dx(1),dy(1),'r*')
text(dx(1),dy(1),'START')

plot(dx(2:end-1),dy(2:end-1),'g.')
plot(dx,dy)

plot(dx(end),dy(end),'r*')
text(dx(end),dy(end),'STOP')

toc
%x,y minimum, f(minimum)
%liczba iteracji
%liczba iteracji gdzie algorytm zmienil polozenie
%czas   http://geatbx.com/docu/fcnindex-01.html#TopOfPage


%1 ma dzialac 2 i 3 klopoty
%ma dzialac dla dowolnego pkt z zakresu
%-2 i 3 to gora 
%3 iteracje ok bo ma miec jak najmniej
%mozna wiecej kierunkow dodac
%3 funkcja 
%skonczyc na kolejne
%bedziemy testowac na next zajeciach
%najwiecej pkt jesli szybko sie wykona
%