clc
close
clear

tic
hold on;

x=0:0.01:2;
a=0;
b=2;
L0=b-a;
y=@(x)5.*x^2-12.*x-3;
l=abs(a-b);
xm0=(a+b)/2;
minimumx=xm0;
minimumy=y(xm0);
x1=(a+(0.25*l));
x2=(b-(0.25*l));

if(y(x1)<minimumy)
    minimumy=y(x1);
    minimumx=x1;
end



toc