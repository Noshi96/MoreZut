n=get(edycja1,'String')

napis=uicontrol('Style','text','String',n,'Position',[100,300,200,50])
