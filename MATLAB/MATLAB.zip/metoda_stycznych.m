clc
close
clear
hold on;
grid on;

f=@(x)sin(x);

a=10;
b=10;
x0=5;
xp=1.05;
h=0.0001;
dok=0.001;

x=a:0.01:b
%s=1.05;

  

i=1;
xm(i)=xp;
df(xp)=((f(xp+h)-f(xp-h))/(2*h));
while  abs(f(xp))>dok;
    i=i+1;
    xm(i)=xp;
    
    xp=xp-(f(xp)/df(xp)); 
end
 
plot(xp,f(xp),'*');

hold off;
%plot(a,f(x),'*');

