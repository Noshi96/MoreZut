%z=peaks;  %wzor i mesh grid
[x,y]=meshgrid([-3:0.1:3],[-3:0.1:3]);
% Rosenbrock   %z=z(x,y)
z=@(x,y) (100.*(y-x.^2).^2+(1-x).^2)
surf(x,y,z(x,y));
axis tight
set(gca, 'nextplot', 'replacechildren','visible','off')
f=getframe
for k=1:20
    %surf(cos(2*pi*k/20)*z(x,y),z(x,y));%z(x,y)
    view(10*k,60)
    f(k)=getframe
end
