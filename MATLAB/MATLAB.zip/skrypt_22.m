clc
clear
close

x=[-5,-3,-1,0,1,2,7]
y=[7,4,2,0,1,3,5]


plot(x,y,'p')
plot(x,y)
z=linspace(-1,1,100)
p=1./(25+z.^z)
plot(z,p,'o')

zz=linspace(-1,1,100)
pp=1./(25+zz.^2)
plot(zz,pp)

