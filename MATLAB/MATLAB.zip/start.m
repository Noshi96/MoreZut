clc
close
clear

czytaj=importdata('dane4.txt');

A=czytaj(:,1:end-1);
B=czytaj(:,end);

wynik=swora_g(A,B)