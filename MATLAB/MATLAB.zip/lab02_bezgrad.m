clc
clear
close

tic
[x,y]=meshgrid([-5:0.1:5],[-5:0.1:5]);
%[x,y]=meshgrid([-2:0.1:2],[-1:0.1:3]);
%[x,y]=meshgrid([-20:0.1:20],[-20:0.1:20]);
x0=-1;  
y0=-1;   
k=3;
dokl=0.0001;
dx(1)=x0;
dy(1)=y0;

f1=@(x,y) (x.^2)+(y.^2);
%f1=@(x,y) (100*(y-(x.^2)).^2)+(1-x).^2;
%f1=@(x,y) -(cos(x).*cos(y).*exp(-(  ((x-pi).^2) + (y-pi).^2)));

subplot(2,1,1)
mesh(x,y,f1(x,y))
subplot(2,1,2)
[c,h]=contour(x,y,f1(x,y))
title('Metoda spadku wzgl�dem wsp�rz�dnych')
%axis square
clabel(c,h)
hold on
czybyl=0;
iteracje=1;

while(k>dokl)
    [w,p]=min([f1(x0,y0),f1(x0,y0+k),f1(x0+k,y0),f1(x0,y0-k),f1(x0-k,y0),f1(x0+k,y0+k),f1(x0+k,y0-k),f1(x0-k,y0-k),f1(x0-k,y0+k)]);
    iteracje=iteracje+1;            %do p najmniejsza wartosc funkcji
    switch(p)
        case 1
            k=k/2;                  %obecne miejsce zwraca najmniejsza wartosc
            czybyl=czybyl+1;        %nie ma mniejszej wartosci funkcji niz ta w ktorej jestem
            dx(iteracje)=x0;    %wpisanie do wektora pozycje
            dy(iteracje)=y0;
            if(czybyl>6)
               break; 
            end
            continue;
        case 2
            y0=y0+k;            %przesununiecie na kolejna pozycje
            dx(iteracje)=x0;
            dy(iteracje)=y0;
           czybyl=0;
            continue;
        case 3
            x0=x0+k;
            dx(iteracje)=x0;
            dy(iteracje)=y0;
            czybyl=0;
            continue;
        case 4
            y0=y0-k;
            dx(iteracje)=x0;
            dy(iteracje)=y0;
            czybyl=0;
            continue;
        case 5
            x0=x0-k;
            dx(iteracje)=x0;
            dy(iteracje)=y0;
            czybyl=0;
           continue;   
         case 6
            x0=x0+k;
            y0=y0+k;
            dx(iteracje)=x0;
            dy(iteracje)=y0;
            czybyl=0;
           continue;   
          case 7
            x0=x0+k;
            y0=y0-k;
            dx(iteracje)=x0;
            dy(iteracje)=y0;
            czybyl=0;
           continue; 
        case 8
            x0=x0-k;
            y0=y0-k;
            dx(iteracje)=x0;
            dy(iteracje)=y0;
            czybyl=0;
           continue; 
         case 9
            x0=x0-k;
            y0=y0+k;
            dx(iteracje)=x0;
            dy(iteracje)=y0;
            czybyl=0;
           continue; 
    end  
end

plot(dx(1),dy(1),'r*')
text(dx(1),dy(1),'START')
plot(dx(end),dy(end),'r*')
text(dx(end),dy(end),'STOP')

plot(dx(2:end-1),dy(2:end-1),'g.') %rysuje ca�a sciezke
plot(dx,dy)

toc
%
%wspolrzedne punktu minimum
x0
y0
%wartosc funkcji w punkcie minimum
f1(x0,y0)
%liczba iteracji odcink�w
iteracje-1


%x,y minimum, f(minimum)
%liczba iteracji
%liczba iteracji gdzie algorytm zmienil polozenie
%czas   http://geatbx.com/docu/fcnindex-01.html#TopOfPage


%1 ma dzialac 2 i 3 klopoty
%ma dzialac dla dowolnego pkt z zakresu
%-2 i 3 to gora 
%3 iteracje ok bo ma miec jak najmniej
%mozna wiecej kierunkow dodac
%3 funkcja 
%skonczyc na kolejne
%bedziemy testowac na next zajeciach
%najwiecej pkt jesli szybko sie wykona
%
%axis square
%zamiast case mozna wektor krok 1 i 360 zakres