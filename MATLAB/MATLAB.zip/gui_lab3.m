function varargout = gui_lab3(varargin)
% GUI_GRAD MATLAB code for gui_grad.fig
%      GUI_GRAD, by itself, creates a new GUI_GRAD or raises the existing
%      singleton*.
%
%      H = GUI_GRAD returns the handle to a new GUI_GRAD or the handle to
%      the existing singleton*.
%
%      GUI_GRAD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_GRAD.M with the given input arguments.
%
%      GUI_GRAD('Property','Value',...) creates a new GUI_GRAD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_grad_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_grad_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_grad

% Last Modified by GUIDE v2.5 18-Apr-2018 22:11:24

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_lab3_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_lab3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_grad is made visible.
function gui_lab3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_grad (see VARARGIN)

% Choose default command line output for gui_grad
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui_grad wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_lab3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function x2_Callback(hObject, eventdata, handles)
% hObject    handle to x2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x2 as text
%        str2double(get(hObject,'String')) returns contents of x2 as a double


% --- Executes during object creation, after setting all properties.
function x2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x1_Callback(hObject, eventdata, handles)
% hObject    handle to x1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x1 as text
%        str2double(get(hObject,'String')) returns contents of x1 as a double


% --- Executes during object creation, after setting all properties.
function x1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function y1_Callback(hObject, eventdata, handles)
% hObject    handle to y1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of y1 as text
%        str2double(get(hObject,'String')) returns contents of y1 as a double


% --- Executes during object creation, after setting all properties.
function y1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to y1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function y2_Callback(hObject, eventdata, handles)
% hObject    handle to y2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of y2 as text
%        str2double(get(hObject,'String')) returns contents of y2 as a double


% --- Executes during object creation, after setting all properties.
function y2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to y2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x0_Callback(hObject, eventdata, handles)
% hObject    handle to x0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x0 as text
%        str2double(get(hObject,'String')) returns contents of x0 as a double


% --- Executes during object creation, after setting all properties.
function x0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function y0_Callback(hObject, eventdata, handles)
% hObject    handle to y0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of y0 as text
%        str2double(get(hObject,'String')) returns contents of y0 as a double


% --- Executes during object creation, after setting all properties.
function y0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to y0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function krok_Callback(hObject, eventdata, handles)
% hObject    handle to krok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of krok as text
%        str2double(get(hObject,'String')) returns contents of krok as a double


% --- Executes during object creation, after setting all properties.
function krok_CreateFcn(hObject, eventdata, handles)
% hObject    handle to krok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dokl_Callback(hObject, eventdata, handles)
% hObject    handle to dokl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dokl as text
%        str2double(get(hObject,'String')) returns contents of dokl as a double


% --- Executes during object creation, after setting all properties.
function dokl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dokl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function func_Callback(hObject, eventdata, handles)
% hObject    handle to func (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of func as text
%        str2double(get(hObject,'String')) returns contents of func as a double


% --- Executes during object creation, after setting all properties.
function func_CreateFcn(hObject, eventdata, handles)
% hObject    handle to func (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in button.
function button_Callback(hObject, eventdata, handles)
% hObject    handle to button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cla
grid on
a = str2double(get(handles.x1,'String'));
b = str2double(get(handles.x2,'String'));
c = str2double(get(handles.y1,'String'));
d = str2double(get(handles.y2,'String'));


[x,y]=meshgrid([a:0.1:b],[c:0.1:d]);
dokl = str2double(get(handles.dokl,'String'));
k = str2double(get(handles.krok,'String'));
x0 = str2double(get(handles.x0,'String'));
y0 = str2double(get(handles.y0,'String'));

f1 = str2func(get(handles.func,'string'));

lambda=1;
 
dx(1)=x0;
dy(1)=y0;
 
axes(handles.axes1)
mesh(x,y,f1(x,y))

axes(handles.axes2)
[c,h]=contour(x,y,f1(x,y))

%axis square
clabel(c,h)
hold on

iteracje=1;

h=0.000001;
 z1=(f1(x0+h,y0)-f1(x0-h,y0))/(2*h);
   z2=(f1(x0,y0+h)-f1(x0,y0-h))/(2*h);
    
    gradient=[z1,z2];

    alfa=lambda/abs(norm(gradient));

    %f1=@(x,y)f1-alfa*gradient;
    
    x0=x0-alfa*gradient(1);
    y0=y0-alfa*gradient(2);
    
    dx(1)=x0;
    dy(1)=y0;



while((norm(gradient))>dokl)
   
   z1=(f1(x0+h,y0)-f1(x0-h,y0))/(2*h);
   z2=(f1(x0,y0+h)-f1(x0,y0-h))/(2*h);
    
    gradient=[z1,z2];

    alfa=lambda/abs(norm(gradient));

    %f1=@(x,y)f1-alfa*gradient;
    
    x0=x0-alfa*gradient(1);
    y0=y0-alfa*gradient(2);
    
    iteracje=iteracje+1
    
    %na next skonczyc, wazne iteracje, programowanie liniowe w matlabie,
    %rownanie prostej przechodzacej przez 2 pkt, oglone wzor prostej,
    %bedziemy kreslic proste i szuka� przeci��
    
    dx(iteracje)=x0;
    dy(iteracje)=y0;
    
    if(iteracje>2)
        if(abs(dx(iteracje)-dx(iteracje-2))<dokl)
            if(abs(dy(iteracje)-dy(iteracje-2))<dokl)
                lambda=lambda/2;
            end
        end
    end
            
end

plot(dx(1),dy(1),'r*')
text(dx(1),dy(1),'START')
plot(dx(end),dy(end),'r*')
text(dx(end),dy(end),'STOP')

plot(dx(2:end-1),dy(2:end-1),'g.') %rysuje ca�a sciezke
plot(dx,dy)
%wspolrzedne punktu minimum
x0
set(handles.minx,'String',x0)
y0
set(handles.miny,'String',y0)

%wartosc funkcji w punkcie minimum
wynik=f1(x0,y0)
set(handles.wynik,'String',wynik)

%liczba iteracji odcink�w
iteracje=iteracje-1
set(handles.iteracje,'String',iteracje)

hold off

 


function iteracje_Callback(hObject, eventdata, handles)
% hObject    handle to iteracje (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of iteracje as text
%        str2double(get(hObject,'String')) returns contents of iteracje as a double


% --- Executes during object creation, after setting all properties.
function iteracje_CreateFcn(hObject, eventdata, handles)
% hObject    handle to iteracje (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function minx_Callback(hObject, eventdata, handles)
% hObject    handle to minx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minx as text
%        str2double(get(hObject,'String')) returns contents of minx as a double


% --- Executes during object creation, after setting all properties.
function minx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function miny_Callback(hObject, eventdata, handles)
% hObject    handle to miny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of miny as text
%        str2double(get(hObject,'String')) returns contents of miny as a double


% --- Executes during object creation, after setting all properties.
function miny_CreateFcn(hObject, eventdata, handles)
% hObject    handle to miny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function wynik_Callback(hObject, eventdata, handles)
% hObject    handle to wynik (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of wynik as text
%        str2double(get(hObject,'String')) returns contents of wynik as a double


% --- Executes during object creation, after setting all properties.
function wynik_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wynik (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
