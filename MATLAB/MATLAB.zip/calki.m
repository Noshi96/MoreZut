clc
close
clear

hold on;

xgora=[0,2,17,24,37,41,50,52];
ygora=[0,2,3,8,8,5,3,0];

xdol=[0,1,7,11,14,17,34,38,39,40,44,50,52];
ydol=[0,-3,-4,-7,-4,-4,-4,-7,-7,-7,-4,-3,0];

xi=min(xgora):0.01:max(xgora);
yi=interp1(xgora,ygora,xi,'cubic')

xi2=min(xdol):0.01:max(xdol);
yi2=interp1(xdol,ydol,xi2,'cubic')

plot(xgora,ygora, 'x')
plot(xi,yi)

plot(xdol,ydol,'x')
plot(xi2,yi2)



N=100;
a=0;
b=52;
d=max(yi);
c=0;

traf=0;

for i=1:N
    x1 = (rand*b)+a;
    y1 = (rand*d)+c;
    
    if y1<=interp1(xgora,ygora,x1,'cubic')
       
        tarf=traf+1;
            plot(x1,y1,'g*');
    else
       
         plot(x1,y1,'rO');
    end
end


c=min(yi2);
traf=0;
for i=1:N
    x1 = (rand*b)+a;
    y1 = (rand*d)-abs(c);
    
    if y1>=interp1(xdol,ydol,x1,'cubic');
       
        tarf=traf+1;
            plot(x1,y1,'g*');
    else
       
         plot(x1,y1,'rO');
    end
end

