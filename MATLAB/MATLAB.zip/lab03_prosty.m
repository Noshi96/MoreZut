clc
clear
close

tic

[x,y]=meshgrid([-5:0.1:5],[-5:0.1:5]);

x0=0.1;  
y0=1;
f1=@(x,y)(x.^2+y.^2);
%f1=@(x,y) (100*(y-(x.^2)).^2)+(1-x).^2;
%f1=@(x,y) -(cos(x).*cos(y).*exp(-(  ((x-pi).^2) + (y-pi).^2)));
lambda=1;
dokl=0.001;
dx(1)=x0;
dy(1)=y0;



subplot(2,1,1)
mesh(x,y,f1(x,y))
subplot(2,1,2)
[c,h]=contour(x,y,f1(x,y))
title('Metoda gradient prosty')
%axis square
clabel(c,h)
hold on
czybyl=0;
iteracje=1;
h=0.000001;
   z1=(f1(x0+h,y0)-f1(x0-h,y0))/(2*h);
   z2=(f1(x0,y0+h)-f1(x0,y0-h))/(2*h);
    
    gradient=[z1,z2];

    alfa=lambda/abs(norm(gradient));

    %f1=@(x,y)f1-alfa*gradient;
    
    x0=x0-alfa*gradient(1);
    y0=y0-alfa*gradient(2);
    
    dx(1)=x0;
    dy(1)=y0;


while((norm(gradient))>dokl)
   
   z1=(f1(x0+h,y0)-f1(x0-h,y0))/(2*h);
   z2=(f1(x0,y0+h)-f1(x0,y0-h))/(2*h);
    
    gradient=[z1,z2];

    alfa=lambda/abs(norm(gradient));

    %f1=@(x,y)f1-alfa*gradient;
    
    x0=x0-alfa*gradient(1);
    y0=y0-alfa*gradient(2);
    
    iteracje=iteracje+1
    
    %na next skonczyc, wazne iteracje, programowanie liniowe w matlabie,
    %rownanie prostej przechodzacej przez 2 pkt, oglone wzor prostej,
    %bedziemy kreslic proste i szuka� przeci��
    
    dx(iteracje)=x0;
    dy(iteracje)=y0;
    
    if(iteracje>2)
        if(abs(dx(iteracje)-dx(iteracje-2))<dokl)
            if(abs(dy(iteracje)-dy(iteracje-2))<dokl)
                lambda=lambda/2;
            end
        end
    end
            
end

plot(dx(1),dy(1),'r*')
text(dx(1),dy(1),'START')
plot(dx(end),dy(end),'r*')
text(dx(end),dy(end),'STOP')

plot(dx(2:end-1),dy(2:end-1),'g.') %rysuje ca�a sciezke
plot(dx,dy)

toc
%
%wspolrzedne punktu minimum
x0
y0
%wartosc funkcji w punkcie minimum
f1(x0,y0)
%liczba iteracji odcink�w
iteracje-1


%x,y minimum, f(minimum)
%liczba iteracji
%liczba iteracji gdzie algorytm zmienil polozenie
%czas   http://geatbx.com/docu/fcnindex-01.html#TopOfPage


%1 ma dzialac 2 i 3 klopoty
%ma dzialac dla dowolnego pkt z zakresu
%-2 i 3 to gora 
%3 iteracje ok bo ma miec jak najmniej
%mozna wiecej kierunkow dodac
%3 funkcja 
%skonczyc na kolejne
%bedziemy testowac na next zajeciach
%najwiecej pkt jesli szybko sie wykona
%
%axis square
%zamiast case mozna wektor krok 1 i 360 zakres