clc
close
clear

m=100;
x0=ones(m,1);
x1=rand(m,1);
x2=[rand(m/2,1)*0.4+0.6;rand(m/2,1)*0.4];
y=[ones(m/2,1);-ones(m/2,1)];

D=[x0,x1,x2,y];


hold on;
scatter(D(1:m/2,2),D(1:m/2,3),'g')
scatter(D(m/2+1:end,2),D(m/2+1:end,3),'r')


[w,k]=wdsfun(D, 1);

x1=[0,1];
x2=-(w(1)+w(2)*x1)/w(3);
plot(x1,x2)


%%Zad dom w pdf punkty po za klasa i w klasie (2 klasy)  
%%Podnoszenie wymiarowosci przekszta�ci� tylko dane + warunek stopu z ifem
%WEj�ci�wka z perceptronu 
%
%



