clc
clear all
close all
 
a = 3;
b = 4;
x = [a:0.01:b];
h = 0.0001;
counter = 0;
 
%f = @(x)((1/3.*x.^2) - (13/7.*x) + 11);
f = @(x) 1/3.*((x-3).^3) + (x-4).^2;
df = @(x)(f(x+h) - f(x-h))/(2.*h);
 
if ((df(a) < 0) && (df(b) > 0))
   
    z = (3.*(f(a) - f(b))/(b-a)) + df(a) + df(b);
        q = sqrt(z.^2 - df(a).*df(b));
        xm = b - ((df(b) + q - z)/(df(b) - df(a) + 2.*q)) .* (b-a);
        counter = 1;
       
    while (df(xm) > h)
        z = (3.*(f(a) - f(b))/b-a) + df(a) + df(b);
        q = sqrt(z.^2 - df(a).*df(b));
        xm = b - ((df(b) + q - z)/(df(b) - df(a) + 2.*q)) .* (b-a);
        counter = counter + 1;
       
        if (df(xm) < 0)
            a = xm;
        end
       
        if (df(xm) > 0)
            b = xm;
        end
    end
end
 
plot(x,f(x))
hold on
plot(xm,f(xm),'*r')
 
disp(xm);
disp(counter);