clc
close
clear

x=1:2:11;
y=0.01:0.01:0.06;

z=[0.815 0.663 0.643 0.641 0.6405 0.643;
    0.82 0.679 0.661 0.662 0.663 0.681;
    0.825 0.685 0.68 0.683 0.698 0.719;
    0.83 0.698 0.694 0.714 0.721 0.748;
    0.835 0.715 0.716 0.724 0.746 0.786;
    0.842 0.72 0.724 0.745 0.779 0.823];

[X,Y]=meshgrid(x,y)

%Vq = interp2(X,Y,V,Xq,Yq)


XX=8; YY=0.03;

wykres=0.685;

subplot(2,3,1)

Vq= interp2(X,Y,z,XX,YY,'nearest');
mesh(X,Y,z)

%F=(wykrs-Vq)^2+(wykres-)

title('nearest');

subplot(2,3,2)
Vq= interp2(X,Y,z,XX,YY,'linear');
mesh(X,Y,z)
title('linear');

subplot(2,3,3)
Vq= interp2(X,Y,z,XX,YY,'spline');
mesh(X,Y,z)
title('spline');

subplot(2,3,4)
Vq= interp2(X,Y,z,XX,YY,'cubic');
mesh(X,Y,z)
title('cubic');


%(w1-n1)^2 + 
%hold on

%W1-n1.^2 (sqrt)

xx=1:0.5:11;
yy=0.01:0.002:0.06;
[XX, YY]=meshgrid(xx,yy)

%W=F(XX,YY);
%mesh(XX,YY,W)
