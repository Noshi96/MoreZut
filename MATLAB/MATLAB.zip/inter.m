clc
close
clear

hold on;

x=-1:0.01:1;
y=1./(25.*x.^2+1);

xw=linspace(-1,1,3);
yw=1./(25.*xw.^2+1);
plot(xw,yw,'*')
plot(x,y);
n=length(xw);
V=ones(n);

for i=2:n
    V(:,i)=xw.^(i-1) %macierz vandermounda
end
    A=inv(V)*yw' %apostrof transponuje
    
    W=A(3)*x.^3+A(2)*x.^2+A(1)*x.^1
    plot(x,W)
    
